package com.example.clashroyale.model;

import java.util.List;

public class RestClashResponse {

    private  List<Items> items;

    public  List<Items> getItems() {
        return items;
    }

    public void setItems(List<Items> items) {
        this.items = items;
    }
}
